package pl.pjwstk.App;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class KlientServiceTestyIntegracyjne {

    @Autowired
    private BankService bankService;

    @Autowired
    private BankStorage bankStorage;

    @Test
    public void testStworzKonto() {
        bankService.stworzKonto(1, 10);
        Klient klient = bankStorage.saldoPoId(1);
        assertNotNull(klient);
        assertEquals(1, klient.getId());
        assertEquals(10, klient.getSaldo());
    }
}