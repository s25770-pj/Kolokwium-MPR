package pl.pjwstk.App;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class KlientServiceTesty {
    @Mock
    private BankStorage bankStorage;

    @InjectMocks
    private BankService bankService;

    @Test
    public void tworzenieKonta() {

        int id = 1;
        int saldo = 500;

        Klient przewidywanyWynik = new Klient(id, saldo);

        bankService.stworzKonto(id, saldo);

        when(bankService.saldoPoId(id)).thenReturn(przewidywanyWynik);
        Klient aktualneKonto = bankStorage.saldoPoId(id);
        assertEquals(przewidywanyWynik, aktualneKonto);
    }

    @Test
    public void klientPoId() {

        int id = 1;
        int saldo = 200;

        Klient przewidywanyWynik = new Klient(id, saldo);

        when(bankStorage.saldoPoId(id)).thenReturn(przewidywanyWynik);

        Klient aktualneKonto = bankStorage.saldoPoId(id);

        assertEquals(przewidywanyWynik, aktualneKonto);
    }
}
