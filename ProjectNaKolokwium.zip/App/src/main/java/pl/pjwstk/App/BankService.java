package pl.pjwstk.App;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BankService {
    private BankStorage bankStorage;

    public BankService(BankStorage bankStorage){
        this.bankStorage = bankStorage;
    }

    public void stworzKonto(int id, int saldo) {
        Klient klient = new Klient(id, saldo);
        bankStorage.stworzKonto(klient);
    }

    public Klient saldoPoId(int id){
        return bankStorage.saldoPoId(id);
    }

    public void wplataNaKonto(int id, int kwota, int noweSaldo){
        Klient klient = bankStorage.saldoPoId(id);
        if (klient != null) {
            noweSaldo += kwota;
            klient.setSaldo(noweSaldo);
        }
    }

//    public void wplataPieniedzy(int id, int kwota) {
//        Klient klient = bankStorage.saldoPoId(id);
//        if (klient != null) {
//            bankStorage.saldoPoId(id) += kwota;
//        }
//    }
//
//    public void tworzeniePrzelewu(int id, String newStatus){
//        Klient klient = bankStorage.saldoPoId(id);
//        if (klient != null) {
//            klient.(newStatus);
//        }
//    }

    public void usunKonto(int id) {
        bankStorage.usunKonto(id);
    }

    public List<Klient> wyswietlWszystkieKontaKlientów() {
        return bankStorage.wypiszKlientow();
    }

}

