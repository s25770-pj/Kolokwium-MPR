package pl.pjwstk.App;

public class Przelew {
    private int id;
    private int kwota;

    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKwota() {
        return kwota;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Przelew(int id, int kwota, String status) {
        this.id = id;
        this.kwota = kwota;
        this.status = status;
    }

    public void setKwota(int kwota) {
        this.kwota = kwota;
    }

}
