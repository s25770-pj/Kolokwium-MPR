package pl.pjwstk.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppApplication {
    private final BankService bankService;

    public AppApplication(BankService bankService, BankService bankService1) {
        this.bankService = bankService;
    }
    public static void main(String[] args) {
        SpringApplication.run(AppApplication.class, args);
    }

}
