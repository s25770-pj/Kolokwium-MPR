package pl.pjwstk.App;

import com.sun.jdi.connect.AttachingConnector;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BankStorage {
    private List<Klient> klients = new ArrayList<>();
    private List<Przelew> przelewy = new ArrayList<>();

    public void stworzKonto(Klient klient) {
        klients.add(klient);
    }

    public void wykonajPrzelew(Przelew przelew) {
        przelewy.add(przelew);
    }

    public void noweSaldo(Klient klient){
        for (int i = 0; i < klients.size(); i++) {
            if(klients.get(i).getId() == klient.getId()){
                klients.set(i, klient);
                break;
            }
        }
    }
    public Klient saldoPoId(int id) {
        for (Klient klient : klients) { //sprawdzanie listy z iteracją
            if (klient.getId() == id) {
                return klient;
            }
        }
        return null;
    }
    public List<Klient> wypiszKlientow(){
        return klients;
    }

    public void usunKonto(int id) {
        for (int i = 0; i < klients.size(); i++) {
            if (klients.get(i).getId() == id) {
                klients.remove(i);
                break;
            }
        }
    }
    public List<Klient> getKlients() {
        return klients;
    }

    public void setKlients(List<Klient> klients) {
        this.klients = klients;
    }

    public BankStorage(List<Klient> klients) {
        this.klients = klients;
    }

}
